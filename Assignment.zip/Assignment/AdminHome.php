<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VeecoTech Official Website</title>
  <link rel="stylesheet" type="text/css" href="background.css"/>


</head>

<body>

<div style=" position:fixed; width:100%">
<table width="100%" style="border-top-width:thick" bgcolor="white" >
<tr>
    <td style="width: 95px"><a href="Home.php"><img src="Photos/Veecotech.png"height="70%" width="50%"/></a></td>
	
    <th style="width: 10%;"><a href="AdminDashboard.php" style="text-decoration:none;color:black">Dashboard</a></th>
    <th style="width: 10%;"><a href="index.php" style="text-decoration:none;color:black">About Us</a></th>
	<td style=" width: 10px;">
	</td>
</tr>
</table>
</div>
<table width="100%">
	<tr align="center" style="background-color:rgba(00,00,00,0.5)">
		<td>
			<span><img src="Photos/laptop.jpg" width="90%" /></span>
		
		</td>
	</tr>
</table>
<div align="center" >
			<table width="100%" id="aboutus" style="color:#D8D8D8;text-align:center;font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif
					;font-size:medium;background-color:rgba(00,00,00,0.9)">
				<tr>
					<td class="abH">
					ABOUT</td>
					<td class="abH">
					LEARN MORE</td>
				</tr>
				<tr>
					<td>
					<div style="background-color:rgba(255,255,255,0.7)">
						<table >
							<tr>
								<td  >
								<br/><br/><br/><br/><br/><br/>
								</td>
							</tr>
						</table>
					</div>
					</td>
					<td>
						<div style="background-color:rgba(255,255,255,0.5)">
						<table>
							<tr>
								<td>
								<br/><br/><br/><br/><br/><br/>
								</td>
							</tr>
						</table>	
						</div>
					</td>
				</tr>
			</table>
			
		<div style="background-color:black">
			<table class="sitemap" width="95%">
				<tr>
					<td width="50%">
					<a>hhhhhhhhhhhhhhhhhhhhhhhhhhhhh</a>
					</td>
				</tr>
				<tr>
					<td width="50%">
						<a>HHHHHHHHHHHHHHHHHHHHHHHHHHHHHH</a>
					</td>
				</tr>
			</table>
		</div>
</div>
</body>
</html>
